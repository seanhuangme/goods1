## TabCount
#### Displays the number of chrome tabs.

#####  [Download at chrome web store](https://chrome.google.com/webstore/detail/tab-count/cflfdplhfcgapcgcahckkadgghpkhfco)

![img2](https://user-images.githubusercontent.com/10740681/125083475-1f216100-e0d1-11eb-98ce-98a8c061676b.png)

![img1](https://user-images.githubusercontent.com/10740681/125083480-2183bb00-e0d1-11eb-9e7d-7563db6101c2.png)

