#!/usr/bin/python3
#coding=utf-8

import sys
import os
import getopt

sys.path.append(f"{os.path.dirname(os.path.realpath(__file__))}/Lib")
import NewFeature
from Entity import Entity
from Tasks import *

def main():
    featureName = input("Please input the name of new feature: ")
    entitys = input("Which entitys do you want to open for this new feature [e.g. HK,IN,MY,SG]: ")
    print("")

    entityStringList = entitys.split(",")

    entitysOpened = []
    for entity in Entity:
        if entity.value in entityStringList:
            entitysOpened.append(entity)

    # ------------------------------------------------------------------------------
    # 
    # ------------------------------------------------------------------------------
    # print(entitysOpened)
    newFeature = NewFeature.NewFeature(featureName=featureName, entitysOpened=entitysOpened)

    # ------------------------------------------------------------------------------
    # 
    # ------------------------------------------------------------------------------
    taskClassList = [
        TaskModule_SweepInvestFeatureConfig_JSON_HK.Task,
        TaskModule_SweepInvestFeatureConfig_JSON_IN.Task,
        TaskModule_SweepInvestFeatureConfig_JSON_MY.Task,
        TaskModule_SweepInvestFeatureConfig_JSON_SG.Task,
        TaskModule_SweepFeatureModel.Task,
        TaskModule_SweepFeatureConfiguration_Test.Task,
        TaskModule_SweepFeatureConfiguration.Task,
        TaskModule_ExtensionUtility_IN.Task,
        TaskModule_ExtensionUtility_MY.Task,
        TaskModule_ExtensionUtility_SG.Task,
    ]

    for taskClass in taskClassList:
        taskClass(newFeature=newFeature).execute()

if __name__ == "__main__":
    main()


