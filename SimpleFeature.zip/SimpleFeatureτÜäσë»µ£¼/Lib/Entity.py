from enum import Enum, unique

@unique
class Entity(Enum):
    COMMON = "COMMON"
    IN = "IN"
    SG = "SG"
    HK = "HK"
    MY = "MY"
