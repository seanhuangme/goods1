

class TaskBase:
    newFeature = None
    placeholderText = '###FeatureName###'
    fileWithRange = None
    patternDicts = []
    
    lines = []
    textOrigin = ""
    textDealing = ""

    def __init__(self):
        pass
    
    def loadFile(self):
        print(f'''正在读取... "{self.fileWithRange.filePath}[{self.fileWithRange.lineNumStart}:{self.fileWithRange.lineNumEnd}]"''')
        with open(self.fileWithRange.filePath, "r") as f:
            self.lines = f.readlines()
            self.textOrigin = "".join(self.lines[self.fileWithRange.lineNumStart:self.fileWithRange.lineNumEnd])

    def execute(self):
        self.loadFile()

        # print(self.textOrigin)
        self.textDealing = self.textOrigin

        print(f"开始处理...")
        for patternDict in self.patternDicts:
            self.executeSignle(patternDict)
        print(f"处理结束\n")

        # print(self.textDealing)
        # print('-', self.fileWithRange.lineNumStart)
        # print('-', self.fileWithRange.lineNumEnd)
        # print('-', self.fileWithRange.lineNumMax)

        textWhole =  "".join(self.lines[0:self.fileWithRange.lineNumStart]) + self.textDealing + "".join(self.lines[self.fileWithRange.lineNumEnd:self.fileWithRange.lineNumMax])
        # print(textWhole)

        with open(self.fileWithRange.filePath, "w") as f:
            f.write(textWhole)

    def executeSignle(self, patternDict):
        keyword = patternDict["keyword"]
        tpl = patternDict["tpl"].replace(self.placeholderText, self.newFeature.featureName)

        if tpl in self.textOrigin:
            return

        replaced = f'''{tpl}
{keyword}'''

        self.textDealing = self.textDealing.replace(keyword, replaced)
        # print(self.textDealing)
        # print(f'[{keyword}]')
        # print(f'[{replaced}]')




