from Entity import Entity

class FileWithRangeBase:
    filePath = ""
    lineNumStart = 0
    lineNumEnd = 0
    lineNumMax = 0
    entity = Entity.COMMON

    def __init__(self, filePath, lineNumStart, lineNumEnd, entity):
        self.filePath = filePath
        self.lineNumStart = lineNumStart
        self.lineNumEnd = lineNumEnd
        self.entity = entity

