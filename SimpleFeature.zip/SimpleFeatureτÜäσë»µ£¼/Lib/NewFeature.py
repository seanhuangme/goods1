# coding: utf-8

class NewFeature:
    featureName = "xxxx"
    entitysOpened = []
    
    def __init__(self, featureName, entitysOpened):
        self.featureName = featureName
        self.entitysOpened = entitysOpened


