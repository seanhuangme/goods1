from TaskBase import TaskBase
from FileWithRangeBase import FileWithRangeBase
from Entity import Entity

class FileWithRange(FileWithRangeBase):
    filePath="/Users/seanhuang/1/1002-1/SweepInvestFeatureConfig.json1.txt"
    entity=Entity.SG
    lineNumStart=0
    lineNumEnd=0

    def __init__(self):
        self.lineNumStart = 0

        with open(self.filePath, "r") as f:
            lines = f.readlines()
            self.lineNumMax = len(lines)
            self.lineNumEnd = self.lineNumMax

class Task(TaskBase):
    def __init__(self, newFeature):
        self.newFeature = newFeature
        self.fileWithRange = FileWithRange()

        boolString = "false"
        if self.fileWithRange.entity in self.newFeature.entitysOpened:
            boolString = "true"

        self.patternDicts=[
            dict(
                keyword='''        "alwaysShowAppInfoCard":''',
                tpl=f'''        "{self.placeholderText}": {boolString},'''
            ),
        ]



