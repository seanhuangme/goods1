from TaskBase import TaskBase
from FileWithRangeBase import FileWithRangeBase
from Entity import Entity

class FileWithRange(FileWithRangeBase):
    filePath="1/1002-1/ExtensionUtility.swift"
    entity=Entity.SG
    lineNumStart=0,
    lineNumEnd=0,
    
    def __init__(self):
        self.lineNumStart = 0

        with open(self.filePath, "r") as f:
            lines = f.readlines()
            self.lineNumMax = len(lines)

            for index, line in enumerate(lines):
                if "static func getSGConfig()" in line:
                    self.lineNumStart = index + 1
                    continue

                if self.lineNumStart > 0 and '''"displayFundDetailProductAltNum"''' in line:
                    self.lineNumEnd = index + 1
                    break

class Task(TaskBase):
    def __init__(self, newFeature):
        self.newFeature = newFeature
        self.fileWithRange = FileWithRange()

        # print(self.fileWithRange.lineNumStart)
        # print(self.fileWithRange.lineNumEnd)

        boolString = "false"
        if self.fileWithRange.entity in self.newFeature.entitysOpened:
            boolString = "true"

        self.patternDicts=[
            dict(
                keyword='''            "alwaysShowAppInfoCard":''',
                tpl=f'''            "{self.placeholderText}": {boolString},'''
            ),
        ]
